CREATE DATABASE BDCINE;
use BDCINE;

CREATE TABLE `salas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_sala` int(50) NOT NULL,
  `capacidad_maxima` int (50) NOT NULL,
  `nombre_pelicula` varchar(100),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `salas` VALUES (1,'100','3','Buscando a Nemo');
INSERT INTO `salas` VALUES (1,'80','2','Francotirador');
INSERT INTO `salas` VALUES (1,'120','5','Morgan y los Super Bichillos');

CREATE TABLE `peliculas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `costo_entrada` varchar(45) NOT NULL,
  `fecha` varchar(45) NOT NULL,
  `salas_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`salas_id`),
  KEY `fk_peliculas_salas_idx` (`salas_id`),
  CONSTRAINT `fk_peliculas_salas` FOREIGN KEY (`salas_id`) REFERENCES `salas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ;

INSERT INTO `Peliculas` VALUES (1,'Buscando a Nemo', '3500','2022-10-03','1'),(2,'Francotirador', '4500','2022-12-03','2'),(3,'Morgan y los Super Bichillos', '3000','2022-10-10','3');