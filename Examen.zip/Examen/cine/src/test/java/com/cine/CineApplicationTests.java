package com.cine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CineApplicationTests {

	@Test
	void contextLoads() {
	}

}
