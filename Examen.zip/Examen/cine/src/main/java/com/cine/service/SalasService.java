package com.cine.service;

import com.cine.entity.Salas;
import com.cine.repository.SalasRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author kendalldiazesquivel
 */
@Service
public class SalasService implements ISalasService{

    @Autowired
    private SalasRepository salasRepository;
    
    @Override
    public List<Salas> listSalas() {
        return (List<Salas>) salasRepository.findAll();
    }
    
}
