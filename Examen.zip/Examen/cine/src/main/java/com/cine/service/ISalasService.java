/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.cine.service;

import com.cine.entity.Salas;
import java.util.List;

/**
 *
 * @author kendalldiazesquivel
 */
public interface ISalasService {
  public List<Salas> listSalas();
}
