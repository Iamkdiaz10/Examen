package com.cine.controller;

import com.cine.entity.Peliculas;
import com.cine.entity.Salas;
import com.cine.service.IPeliculaService;
import com.cine.service.ISalasService;
import com.cine.service.SalasService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

/**
 *
 * @author kendalldiazesquivel
 */
@Controller
public class PeliculaController {
    
    @Autowired
    private IPeliculaService peliculaService;
    
    @Autowired
    private ISalasService salasService;
    
    
    @GetMapping("/pelicula")
    public String index (Model model){
        List<Peliculas> listaPelicula = peliculaService.getAllPeliculas();
        model.addAttribute("titulo", "Tabla Peliculas");
        model.addAttribute("peliculas", listaPelicula);
        return "peliculas";
    }
    
    @GetMapping("/peliculaN")
    public String agregarPelicula (Model model){
        List<Salas> listaSalas = salasService.listSalas();
        model.addAttribute("pelicula", new Peliculas());
        model.addAttribute("salas", listaSalas);
        return "crear";
        
    }
    
    @PostMapping("/save")
    public String guardarPelicula(@ModelAttribute Peliculas pelicula){
        peliculaService.savePeliculas(pelicula);
        return "redirect:/pelicula";
    }
    
    @GetMapping("/editPersona/{id}")
    public String editarPersona (@PathVariable("id")Long idPelicula, Model model){
        Peliculas pelicula = peliculaService.getPeliculasById(idPelicula);
        List<Salas> listaSalas = salasService.listSalas();
        model.addAttribute("pelicula",pelicula);
        model.addAttribute("salas", listaSalas);
        return "crear";
    }
    
    @GetMapping("/delete/{id}")
    public String eliminarPelicula(@PathVariable("id") Long idPelicula){
        peliculaService.delete(idPelicula);
        return "redirect:/pelicula";
    }
}
