package com.cine.service;

import com.cine.entity.Peliculas;
import java.util.List;

/**
 *
 * @author kendalldiazesquivel
 */
public interface IPeliculaService {

    public List<Peliculas> getAllPeliculas();

    public Peliculas getPeliculasById(long id);

    public void savePeliculas(Peliculas peliculas);

    public void delete(long id);
}
